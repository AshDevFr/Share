(function() {
  'use strict';

  angular
    .module('blogularApp-articles', ['blogularApp-articles-newArticle']);
})();
